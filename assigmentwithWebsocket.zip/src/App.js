import React from 'react';
import Ticker from './Ticker';

function App() {
  return (
    <Ticker />
  )
}
export default App ;
